
import React, { useEffect, useState } from "react";
import AuthModal from "./components/AuthModal.jsx";
import { getSession, logout, touchSession } from "./sessionService.js";

export default function App() {
  const [open, setOpen] = useState(false);
  const [session, setSession] = useState(getSession());

  useEffect(() => {
    const events = ["mousemove","keydown","click"];
    const update = ()=> { if(session){ const s=touchSession(); if(!s) setSession(null);} };
    events.forEach(e=>window.addEventListener(e, update));
    const timer = setInterval(()=>{ const s=getSession(); if(!s) setSession(null); }, 5000);
    return ()=>{
      events.forEach(e=>window.removeEventListener(e, update));
      clearInterval(timer);
    };
  }, [session]);

  return (
    <div style={{padding:40}}>
      <h1>Popup Auth + Session + Idle Timeout</h1>

      {!session && <button onClick={()=>setOpen(true)}>Login</button>}
      {session && (
        <>
          <p>Logged in as: <b>{session.user.email}</b></p>
          <button onClick={()=>{ logout(); setSession(null); }}>Logout</button>
        </>
      )}

      <AuthModal
        open={open}
        onClose={()=>setOpen(false)}
        onLogin={(u)=>{ setSession(getSession()); }}
      />
    </div>
  );
}
