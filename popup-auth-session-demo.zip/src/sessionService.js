
const KEY = "demo_session";
export const IDLE_TIMEOUT = 3 * 60 * 1000; // 3 mins
export const ABSOLUTE_TIMEOUT = 30 * 60 * 1000; // 30 mins

export function createSession(user){
  const now = Date.now();
  const session = {
    user,
    createdAt: now,
    lastActivity: now
  };
  localStorage.setItem(KEY, JSON.stringify(session));
  return session;
}

export function getSession(){
  const raw = localStorage.getItem(KEY);
  if(!raw) return null;
  try{
    const s = JSON.parse(raw);
    const now = Date.now();
    if(now - s.lastActivity > IDLE_TIMEOUT) { logout(); return null; }
    if(now - s.createdAt > ABSOLUTE_TIMEOUT) { logout(); return null; }
    return s;
  }catch{
    logout();
    return null;
  }
}

export function touchSession(){
  const s = getSession();
  if(!s) return null;
  s.lastActivity = Date.now();
  localStorage.setItem(KEY, JSON.stringify(s));
  return s;
}

export function logout(){
  localStorage.removeItem(KEY);
}
