
import React, { useState } from "react";
import "./authModal.css";
import { createSession } from "../sessionService.js";

export default function AuthModal({ open, onClose, onLogin }) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  if (!open) return null;

  const handleSubmit = (e)=>{
    e.preventDefault();
    const user = { name, email };
    createSession(user);
    onLogin(user);
    onClose();
  };

  return (
    <div className="auth-overlay">
      <div className="auth-modal">
        <button className="auth-close" onClick={onClose}>×</button>
        <h2>{isSignUp ? "Create Account" : "Welcome Back"}</h2>

        <form onSubmit={handleSubmit}>
          {isSignUp && (
            <input placeholder="Full Name" value={name} onChange={(e)=>setName(e.target.value)} required />
          )}
          <input placeholder="Email address" value={email} onChange={(e)=>setEmail(e.target.value)} required />
          <input type="password" placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)} required />
          <button className="auth-btn">{isSignUp ? "Create Account" : "Login"}</button>
        </form>

        <div className="auth-switch">
          {isSignUp ? <>Already have an account?<span onClick={()=>setIsSignUp(false)}> Login</span></> :
          <>New here?<span onClick={()=>setIsSignUp(true)}> Create Account</span></>}
        </div>
      </div>
    </div>
  );
}
